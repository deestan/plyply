﻿using System;
using System.Windows;

namespace AreYouSure
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            new System.Threading.Thread(() =>
            {
                while (true)
                {
                    MessageBox.Show("Are you sure?", "WARNING!",
                                    MessageBoxButton.OKCancel,
                                    MessageBoxImage.Stop);
                    var minutes = new Random().Next(30) + 10;
                    System.Threading.Thread.Sleep(new TimeSpan(0, minutes, 0));
                }
            }).Start();
            Hide();
        }
    }
}
